# Maîtriser le rôle de l'IA — AI-SHADOW-20260920-v1

## Décision

Prioriser la mesure des interventions IA par fonction, plutôt qu'un passage
global en mode actif. Livrer un audit indépendant en lecture seule, sans modifier
les décisions Live ni le scorecard/disjoncteur historique. Version Alfred 1.24.0
inchangée. Les deux expériences de moteur restent intactes.

## Ce que les avis récents disent réellement

Fenêtre d'événements depuis le 17 septembre, photographie horodatée dans le JSON.

- **INJ SHORT** : VETO converti par la configuration en réduction de taille de
  50 %, et non suppression totale. Le trade a perdu 7,75 USDT. La réduction aurait
  diminué la perte d'environ **3,88 USDT** à sortie et rendement constants.
- **ARB SHORT** : même réduction proposée, mais le trade a gagné 4,34 USDT.
  La réduction aurait sacrifié **2,17 USDT**. Solde comptable des deux réductions :
  **+1,71 USDT**, avant coûts IA et effets portefeuille. Deux observations,
  nullement une validation statistique. Coût API d'entrée enregistré : environ
  0,33 USD sur la fenêtre ; les GO ne créent pas une valeur ajoutée mesurable.
- **APT SHORT** : CUT conseillé avec PNL instantané journalisé -11,33 USDT,
  puis perte finale -17,81 USDT. Signal intéressant, mais la série de ticks
  comporte une lacune : **aucun gain exécutable validé** n'est attribué au CUT.
- **ENA LONG** : le rejeu chronologique des 12 propositions LOCK conduit à une
  seule sortie hypothétique, avec environ **+1,67 USDT de différence de prix**
  par rapport à la sortie réelle, hors différence de funding.
- **UNI LONG** : 41 avis LOCK ne constituent pas 41 trades gagnants. Couverture
  temporelle insuffisante pour ce protocole ; aucun score attribué.
- **OP** : position non clôturée au contrôle, avis encore non résolu.

Les coûts API de sortie enregistrés dépassent 3 USD sur cette même fenêtre.
Ce seul LOCK résolu ne permet donc pas de démontrer que la fonction se finance.
Ne pas soustraire ces coûts à une somme mêlant positions incomplètes, différences
de prix et attribution de taille pour annoncer un PNL IA global.
L'abonnement assistant reste un coût séparé en EUR.

## Correction de la méthode de mesure

Le scorecard historique ignore `note=lock_shadow` et son autre chemin LOCK
rejoue le stop depuis l'entrée. Le nouvel audit prend les LOCK shadow valides
et ne les active **qu'après leur horodatage de décision**. Les avis successifs
forment une seule trajectoire par position ; le plancher ne peut que monter.
La sortie LOCK a lieu au tick suivant le franchissement, avec 2 bps de glissement.
Un CUT s'exécute au premier tick après l'avis seulement si la position reste
perdante à ce prix. Une décision arrivée après la sortie n'a aucun effet.

Jointure exacte par symbole et milliseconde d'entrée ; états ambigus, avis agis,
changements de prompt dans une trajectoire et historiques tronqués refusés.
Un trou de plus de 120 secondes exclut toute la trajectoire après décision.
Les modèles et hashes de prompt sont conservés par ligne. Les HOLD et avis
supprimés pour faible confiance ne sont pas évalués par cet outil.

## Limites et suite

Ce diagnostic fixe entrées et tailles réelles. Il ne rejoue pas les places
libérées, les nouveaux signaux, les tailles suivantes ou la réaction d'une IA
face à un portefeuille différent. Le stop emploie le proxy de coûts de 10 bps
actuel ; le delta de sortie omet la différence de funding. Marché échantillonné,
liquidité non modélisée. Les avis ultérieurs ont été produits sur le portefeuille
réel : la simulation n'est pas un portefeuille IA autonome.

Au bilan du 24 septembre, refaire cet audit, comparer les fonctions séparément
et conserver aussi tous les cas défavorables. Une fonction prometteuse devra
ensuite être évaluée prospectivement sur un portefeuille indépendant avant
activation. Ne pas choisir un régime ou une stratégie après quelques exemples
positifs en les présentant comme une règle validée.

## Reproduction

`python3 -m unittest test_exit_protection test_ai_shadow_replay -q` : 14 tests.
`python3 -m backtests.audit_ai_shadow_replay --data-dir alfred/data --since 2026-09-17T00:00:00+00:00 --out /tmp/ai_shadow.json`.

L'outil ouvre les bases en lecture seule. Aucun appel IA, ordre, message ou
écriture de disjoncteur. Rapport compact : `ai_shadow_20260920.json` ; données
figées et scripts : `ai_shadow_20260920.tar.gz`. Le hash des entrées figure dans
le rapport. Ne pas utiliser l'ancien scorecard pour justifier une activation.
