"""Bounded preregistered S1 extension research; no production mutations."""
from dataclasses import replace
from pathlib import Path
import hashlib, json, sqlite3, time
import numpy as np
from alfred import rules
from alfred.settings import DEFAULT_PARAMS
import backtests.backtest_genetic as genetic
import backtests.backtest_rolling as engine
from backtests.backtest_sector import compute_sector_features
from backtests.recheck_macro_2026_09 import ms

ROOT=Path(__file__).resolve().parents[1]
SNAP=Path('/tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot')
DB=Path('/tmp/alfred-cascade-20260917/funding_history.db')
ORIGINAL=rules.evaluate_exit


def decide(pos, ur, m, p, *, variant, counter=None, **kwargs):
    d=ORIGINAL(pos, ur, m, p, **kwargs)
    if variant=='baseline' or not d or d.reason!='timeout': return d
    if pos.strategy!='S1' or pos.extended or ur<=0: return d
    if variant=='macro' and (m.btc_z is None or pos.direction*m.btc_z<=0): return d
    protected=ORIGINAL(replace(pos,hours_to_timeout=1),ur,m,p,**kwargs)
    if protected is not None: return protected
    if counter is not None: counter.append(dict(hours=pos.hours_held,ur=ur,btc_z=m.btc_z,direction=pos.direction))
    return rules.ExitDecision('extend','research_s1_extension',None,24.0)


def main():
    genetic.DATA_DIR=engine.DATA_DIR=str(SNAP)
    data=genetic.load_3y_candles(); oi=engine.load_oi(); dxy=engine.load_dxy()
    features=genetic.build_features(data); sectors=compute_sector_features(features,data)
    funding={}
    with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        for s in DEFAULT_PARAMS.trade_symbols:
            rows=db.execute('SELECT ts,funding_rate FROM funding WHERE symbol=? ORDER BY ts',(s,)).fetchall()
            assert rows,s
            funding[s]=(np.array([r[0] for r in rows],dtype=np.int64),np.array([r[1] for r in rows],dtype=np.float64))
    dates=['2024-09-16T12:00','2025-03-16T12:00','2025-09-16T12:00','2026-03-16T12:00','2026-09-16T12:00']
    output={'protocol_sha256':hashlib.sha256((ROOT/'docs/exit_extension_protocol.md').read_bytes()).hexdigest(),
      'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'engine_sha256':hashlib.sha256((ROOT/'backtests/backtest_rolling.py').read_bytes()).hexdigest(),
      'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SNAP.glob('*.json'))},
      'funding_hashes':{s:hashlib.sha256(v[0].tobytes()+v[1].tobytes()).hexdigest() for s,v in funding.items()},
      'runs':[]}
    for slip in (4.,6.):
        engine.COST=engine.TAKER_FEE_BPS+slip; engine.BACKTEST_SLIPPAGE_BPS=slip
        assert engine.COST in (13,15)
        for start,end in zip(dates,dates[1:]):
            for variant in ('baseline','macro','null'):
                counter=[]; engine._P=DEFAULT_PARAMS
                rules.evaluate_exit=lambda pos,ur,m,p,**kw: decide(pos,ur,m,p,variant=variant,counter=counter,**kw)
                began=time.monotonic()
                try:
                    r=engine.run_window(features,data,sectors,dxy,start_ts_ms=ms(start),end_ts_ms=ms(end)-1,start_capital=500,
                    oi_data=oi,funding_data=funding,apply_adaptive_modulator=True,aligned=True,margin_check=True,
                    mfe_on_close=True,realistic_trail_booking=True)
                finally: rules.evaluate_exit=ORIGINAL
                assert all(t['entry_t'] <= t['exit_t'] and t['entry_t'] < ms(end) for t in r['trades'])
                row={'start':start,'end_exclusive':end,'slip':slip,'cost_ex_funding':engine.COST,'variant':variant,
                    'end_capital':r['end_capital'],'max_dd_pct':r['max_dd_pct'],'n_trades':r['n_trades'],
                    'extensions':counter,'trades':r['trades'],'basket_timeseries':r['basket_timeseries']}
                output['runs'].append(row)
                (ROOT/'docs/exit_extension_results.json').write_text(json.dumps(output,indent=2,default=lambda x:x.item() if hasattr(x,'item') else str(x)))
                print(start,slip,variant,round(r['end_capital'],2),round(r['max_dd_pct'],2),r['n_trades'],'extensions',len(counter),round(time.monotonic()-began,1),flush=True)
if __name__=='__main__': main()
