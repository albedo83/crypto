from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parents[1]
x=json.loads((ROOT/'docs/exit_extension_results.json').read_text())
assert len(x['runs'])==24
out=['# S1 : prolonger une fois les gagnants — résultat borné','',
'**Pas de déploiement.** La prolongation améliore les trois semestres où S1 est actif, mais le filtre macro ne change aucune décision et le risque réalisé se dégrade sur le semestre récent au-delà du seuil préenregistré de 2 points.','',
'Capital initial 500 USD par semestre; frais 9 bps + slippage 4/6 bps, hors funding historique ajouté selon le calcul canonique. Les dollars du tableau ne sont pas des euros et ne financent pas directement un abonnement EUR.','',
'| Slippage | Semestre début | Baseline finalUSD | Prolongation finalUSD | GainUSD | DD réalisé base% | DD réalisé variante% | Extensions |','|---:|---|---:|---:|---:|---:|---:|---:|']
metrics=[]
for slip in (4,6):
    for start in sorted({r['start'] for r in x['runs']}):
        rows={r['variant']:r for r in x['runs'] if r['slip']==slip and r['start']==start}
        b,a,n=rows['baseline'],rows['macro'],rows['null']
        for k in ('end_capital','max_dd_pct','n_trades','extensions','trades','basket_timeseries'): assert a[k]==n[k],(slip,start,k)
        for r in rows.values():
            assert abs(500+sum(t['pnl'] for t in r['trades'])-r['end_capital'])<1e-8
            assert all(t['exit_t']>=t['entry_t'] for t in r['trades'])
        out.append(f"|{slip}|{start[:10]}|{b['end_capital']:.2f}|{a['end_capital']:.2f}|{a['end_capital']-b['end_capital']:+.2f}|{b['max_dd_pct']:.2f}|{a['max_dd_pct']:.2f}|{len(a['extensions'])}|")
        for variant,r in rows.items():
            times=r['basket_timeseries']
            metrics.append({'slip':slip,'start':start,'variant':variant,'turnover_notional':sum(t['size'] for t in r['trades']),
                'fees_plus_slippage_proxy_usd':sum(t['size'] for t in r['trades'])*r['cost_ex_funding']/1e4,
                'mean_positions_sampled':sum(t['n_pos'] for t in times)/len(times),
                'sum_notional_hours':sum(t['size']*(t['exit_t']-t['entry_t'])/3600000 for t in r['trades'])})
out += ['', '## Interprétation et limites','',
'- Première exécution invalidée : le moteur ouvrait deux trades au next-open hors fenêtre puis les clôturait au passé. Garde temporelle ajoutée dans la copie isolée; les 24 runs ont été recalculés sans changer l’hypothèse. Archive suffixe invalid_boundary conservée.',
'- Les variantes macro et null ont exactement les mêmes ledgers, extensions et trajectoires portefeuille sur les 8 couples semestre/coût. **Aucune preuve que BTCz ajoute une information.**',
'- Au semestre récent, gain seulement +12 USD environ sur 500 en six mois; insuffisant pour couvrir 50–100 EUR/mois, même avant frais API/serveur et conversion.',
'- DD fourni par moteur = capital réalisé, pas équité totale. Les pertes ouvertes peuvent être plus grandes. Le parent recalcule séparément un MTM 4h approximatif.',
'- Funding canonique = taux moyen des observations × durée. Données manquantes et intégration approximative ne sont pas corrigées par cette étude. OI de TON périmé depuis juin 2026; limitations héritées du snapshot.',
'- Les fenêtres sont disjointes, mais cet historique a déjà servi à de nombreuses recherches : pas de nouvel échantillon indépendant. Un semestre ne comporte aucun S1 et ne valide rien sur cette hypothèse.',
'- Les inventaires changent après extension (places immobilisées, nouvelles entrées différentes). Les deltas sont portefeuille, pas une attribution causale directe à chaque ancienne entrée.',
'- Extension ne change ni levier, ni sizing initial; elle augmente néanmoins la durée exposée et peut bloquer des occasions.',
'- Dix tests purs passent (dont 36 cas identité baseline); ledgers réconciliés au capital à 1e-8 USD; aucune modification de production.',
'', '## Reproduction','',
'`/home/crypto/.venv/bin/python3 -m backtests.research_exit_extension` depuis cette copie isolée. Protocole `docs/exit_extension_protocol.md`; résultats complets `docs/exit_extension_results.json`; métriques exposition/coûts `docs/exit_extension_metrics.json`. SHA256 des entrées/protocole/script inclus dans résultat.']
(ROOT/'docs/exit_extension_report.md').write_text('\n'.join(out)+'\n')
(ROOT/'docs/exit_extension_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'backtests/backtest_rolling.py',ROOT/'backtests/research_exit_extension.py',ROOT/'backtests/test_research_exit_extension.py',ROOT/'backtests/report_exit_extension.py',ROOT/'docs/exit_extension_protocol.md',ROOT/'docs/exit_extension_results.json',ROOT/'docs/exit_extension_report.md',ROOT/'docs/exit_extension_metrics.json']}
(ROOT/'docs/exit_extension_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('\n'.join(out[:17]))
