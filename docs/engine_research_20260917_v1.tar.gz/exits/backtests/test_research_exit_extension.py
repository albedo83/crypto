import unittest
from dataclasses import replace
from alfred import rules
from alfred.settings import DEFAULT_PARAMS
from backtests.research_exit_extension import decide, ORIGINAL

class ExtensionTests(unittest.TestCase):
    def setUp(self):
        self.pos=rules.PosView('S1',1,100,150,-1250,600,-100,72,0,70)
        self.market=rules.MarketCtx(price=105,btc_z=1)
    def call(self,pos=None,ur=500,market=None,variant='macro',**kw):
        return decide(pos or self.pos,ur,market or self.market,DEFAULT_PARAMS,variant=variant,**kw)
    def test_baseline_identity(self):
        for hours in (24,72,96):
            p=replace(self.pos,hours_held=hours,hours_to_timeout=72-hours)
            for ur in (-1500,-500,0,500):
                for z in (-2,0,2):
                    m=replace(self.market,btc_z=z)
                    self.assertEqual(self.call(p,ur,m,variant='baseline'),ORIGINAL(p,ur,m,DEFAULT_PARAMS))
    def test_macro_direction(self):
        self.assertEqual(self.call().extend_hours,24)
        self.assertEqual(self.call(market=replace(self.market,btc_z=-1)).reason,'timeout')
        self.assertEqual(self.call(replace(self.pos,direction=-1),market=replace(self.market,btc_z=-1)).action,'extend')
    def test_no_signal_no_extension(self):
        for z in (None,0): self.assertEqual(self.call(market=replace(self.market,btc_z=z)).reason,'timeout')
    def test_null_ignores_macro(self):
        self.assertEqual(self.call(market=replace(self.market,btc_z=-1),variant='null').action,'extend')
    def test_one_extension_only(self):
        self.assertEqual(self.call(replace(self.pos,extended=True)).reason,'timeout')
    def test_nonpositive(self):
        for ur in (0,-100): self.assertEqual(self.call(ur=ur).reason,'timeout')
    def test_only_s1(self):
        for strat in ('S5','S8','S9','S10'):
            p=replace(self.pos,strategy=strat)
            self.assertEqual(self.call(p),ORIGINAL(p,500,self.market,DEFAULT_PARAMS))
    def test_catastrophe_precedes_extension(self):
        self.assertEqual(self.call(worst_bps=-1400).reason,'catastrophe_stop')
    def test_floor_precedes_extension(self):
        d=self.call(replace(self.pos,opp_floor_bps=400),worst_bps=300)
        self.assertEqual(d.reason,'opp_floor')
    def test_not_before_timeout(self):
        self.assertIsNone(self.call(replace(self.pos,hours_to_timeout=4)))
if __name__=='__main__': unittest.main()
