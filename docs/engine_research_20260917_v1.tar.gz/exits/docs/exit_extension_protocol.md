# S1 : prolongation conditionnelle au régime — protocole fixé avant calcul

17 septembre 2026. Recherche uniquement; capital initial500 USD par semestre.
Hypothèse : le timeout fixe72h interrompt parfois une tendance macro encore active.
Variante macro : au timeout d'un S1 profitable (rendement prix strictement >0), prolonger UNE fois24h si direction × BTCz courant >0, disponible au close.
Contrôle null : même extension des S1 profitables sans condition BTCz.
Le contrôle distingue la valeur de la condition macro de celle d'un simple hold plus long.
Aucun seuil ajusté après résultats. Baseline puis ces deux variantes seulement.
Les règles canoniques restent prioritaires : ne transformer que la décision timeout;
réévaluer les règles avec délai restant artificiel1h pour préserver les protections
normalement situées après timeout; si une autre sortie s'applique, l'exécuter.
Pas de modification du sizing initial; extension augmente la durée exposée; les changements
ultérieurs d'inventaire sont inclus dans le backtest complet du portefeuille.

Quatre fenêtres disjointes début inclus/fin exclue :
2024-09-16T12:00/2025-03-16T12:00/2025-09-16T12:00/2026-03-16T12:00/2026-09-16T12:00 UTC.
Frais9bps + slippage4 et6bps, funding historique, aligned/margin_check/mfe_on_close/
realistic_trail_booking activés. Paramètres actuels, macro4slots inchangé.
Snapshots figés /tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot;
funding /tmp/alfred-cascade-20260917/funding_history.db lu mode=ro.
Publier dollars, DD, nombre trades et extensions, différences et trades complets.
Critère indicatif poursuite : gain positif dans au moins3 fenêtres actives sans
DD aggravé>2points; vérifier le contrôle null. Si fréquence trop faible, indéterminé.
Même un passage reste rétrospectif : données déjà explorées, aucun vrai hors-échantillon.
Anciennes recherches consultées : runner_extension (MFE et proximité du pic),
slow_bleed (rejet aligned), reversal_exit, div_erosion, exit_chain_ablation.
Nouveauté limitée : condition macro courante au timeout S1; pas invention de la prolongation.

Correction méthodologique après premier calcul, sans retune : le parent a détecté des entrées next-open hors fenêtre puis liquidées au passé (exit < entry). Premier résultat archivé INVALID_BOUNDARY. Filtrer next-open > end_ts_ms avant entrée; recalculer les24runs identiques. Exiger exit>=entry et entry<borneexclusive dans tous les ledgers. DD canonique réalisé seulement.
