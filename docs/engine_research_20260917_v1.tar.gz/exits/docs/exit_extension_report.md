# S1 : prolonger une fois les gagnants — résultat borné

**Pas de déploiement.** La prolongation améliore les trois semestres où S1 est actif, mais le filtre macro ne change aucune décision et le risque réalisé se dégrade sur le semestre récent au-delà du seuil préenregistré de 2 points.

Capital initial 500 USD par semestre; frais 9 bps + slippage 4/6 bps, hors funding historique ajouté selon le calcul canonique. Les dollars du tableau ne sont pas des euros et ne financent pas directement un abonnement EUR.

| Slippage | Semestre début | Baseline finalUSD | Prolongation finalUSD | GainUSD | DD réalisé base% | DD réalisé variante% | Extensions |
|---:|---|---:|---:|---:|---:|---:|---:|
|4|2024-09-16|811.33|855.77|+44.44|-37.48|-37.48|27|
|4|2025-03-16|707.25|734.84|+27.59|-31.49|-31.49|11|
|4|2025-09-16|1743.58|1743.58|+0.00|-23.26|-23.26|0|
|4|2026-03-16|524.06|536.23|+12.17|-32.62|-35.89|16|
|6|2024-09-16|797.62|841.76|+44.14|-37.72|-37.72|27|
|6|2025-03-16|696.19|723.56|+27.37|-31.80|-31.80|11|
|6|2025-09-16|1716.85|1716.85|+0.00|-23.36|-23.36|0|
|6|2026-03-16|514.39|526.43|+12.04|-33.14|-36.38|16|

## Interprétation et limites

- Première exécution invalidée : le moteur ouvrait deux trades au next-open hors fenêtre puis les clôturait au passé. Garde temporelle ajoutée dans la copie isolée; les 24 runs ont été recalculés sans changer l’hypothèse. Archive suffixe invalid_boundary conservée.
- Les variantes macro et null ont exactement les mêmes ledgers, extensions et trajectoires portefeuille sur les 8 couples semestre/coût. **Aucune preuve que BTCz ajoute une information.**
- Au semestre récent, gain seulement +12 USD environ sur 500 en six mois; insuffisant pour couvrir 50–100 EUR/mois, même avant frais API/serveur et conversion.
- DD fourni par moteur = capital réalisé, pas équité totale. Les pertes ouvertes peuvent être plus grandes. Le parent recalcule séparément un MTM 4h approximatif.
- Funding canonique = taux moyen des observations × durée. Données manquantes et intégration approximative ne sont pas corrigées par cette étude. OI de TON périmé depuis juin 2026; limitations héritées du snapshot.
- Les fenêtres sont disjointes, mais cet historique a déjà servi à de nombreuses recherches : pas de nouvel échantillon indépendant. Un semestre ne comporte aucun S1 et ne valide rien sur cette hypothèse.
- Les inventaires changent après extension (places immobilisées, nouvelles entrées différentes). Les deltas sont portefeuille, pas une attribution causale directe à chaque ancienne entrée.
- Extension ne change ni levier, ni sizing initial; elle augmente néanmoins la durée exposée et peut bloquer des occasions.
- Dix tests purs passent (dont 36 cas identité baseline); ledgers réconciliés au capital à 1e-8 USD; aucune modification de production.

## Reproduction

`/home/crypto/.venv/bin/python3 -m backtests.research_exit_extension` depuis cette copie isolée. Protocole `docs/exit_extension_protocol.md`; résultats complets `docs/exit_extension_results.json`; métriques exposition/coûts `docs/exit_extension_metrics.json`. SHA256 des entrées/protocole/script inclus dans résultat.
