import unittest
import numpy as np
from validate import metrics,decompose
class Tests(unittest.TestCase):
 def base(self):
  t=dict(coin='X',strat='S1',dir=1,entry_t=0,exit_t=3600000,size=100.,pnl=10.)
  b=[dict(ts=0,capital=500,basket_unreal=0,n_pos=1),dict(ts=3600000,capital=500,basket_unreal=10,n_pos=1),dict(ts=7200000,capital=510,basket_unreal=0,n_pos=0)]
  return dict(trades=[t],basket_timeseries=b,end_capital=510,max_dd_pct=0)
 def test_cost_not_double_charged_and_missing_mark_counted(self):
  f={'X':(np.array([0,3600000]),np.array([.001,.001]),np.array([0,.001,.002]))}
  m=metrics(self.base(),13,f,{'X':{0}})
  self.assertAlmostEqual(m['minimum_equity_proxy'],499.87)
  self.assertEqual(m['open_position_bars_without_price'],1)
  self.assertAlmostEqual(m['notional_hours'],100)
 def test_decomposition_identity(self):
  a=self.base();b=self.base();b['trades'][0].update(size=200,pnl=30);b['end_capital']=530
  d=decompose(a,b);self.assertAlmostEqual(d['size_component'],10);self.assertAlmostEqual(d['paired_net_return_component'],10);self.assertAlmostEqual(d['delta'],20)
 def test_reverse_chronology_rejected(self):
  a=self.base();a['trades'][0]['entry_t']=7200000
  with self.assertRaises(AssertionError):metrics(a,13,{})
if __name__=='__main__':unittest.main()
