"""Independent cross-agent accounting, chronology, baseline and 4h risk audit."""
from pathlib import Path
import gzip,json,sqlite3,hashlib
import numpy as np
ROOT=Path('/tmp/alfred-research-control-20260917')
FUND=Path('/tmp/alfred-cascade-20260917/funding_history.db')

def read(p):
 if str(p).endswith('.gz'):
  with gzip.open(p,'rt') as f:return json.load(f)
 return json.loads(Path(p).read_text())

def key(t):return t['coin'],t['strat'],t['dir'],t['entry_t']

def decompose(base,var):
 a={key(t):t for t in base['trades']};b={key(t):t for t in var['trades']}
 assert len(a)==len(base['trades']) and len(b)==len(var['trades'])
 common=a.keys()&b.keys()
 size=sum((b[k]['size']-a[k]['size'])*(a[k]['pnl']/a[k]['size']) for k in common)
 ret=sum(b[k]['size']*(b[k]['pnl']/b[k]['size']-a[k]['pnl']/a[k]['size']) for k in common)
 unmatched=sum(b[k]['pnl'] for k in b.keys()-a.keys())-sum(a[k]['pnl'] for k in a.keys()-b.keys())
 delta=var['end_capital']-base['end_capital']
 assert abs(delta-size-ret-unmatched)<1e-7
 return {'matched':len(common),'baseline_only':len(a.keys()-b.keys()),'variant_only':len(b.keys()-a.keys()),'size_component':size,'paired_net_return_component':ret,'unmatched_component':unmatched,'delta':delta,'interpretation':'Accounting decomposition, not causal attribution; paired selection is endogenous.'}

def metrics(r,cost,funding,price_times=None):
 trades=r['trades'];basket=r['basket_timeseries'];end=r['end_capital']
 assert abs(end-500-sum(t['pnl'] for t in trades))<1e-7
 assert all(t['entry_t']<=t['exit_t'] and t['size']>0 for t in trades)
 ts=np.array([b['ts'] for b in basket],dtype=np.int64)
 cap=np.array([b['capital'] for b in basket]);ur=np.array([b['basket_unreal'] for b in basket])
 open_n=np.zeros(len(ts));notional=np.zeros(len(ts));fund=np.zeros(len(ts));realized=np.full(len(ts),500.)
 exposure_hours=0.; missing_marks=0
 for tr in trades:
  opened=(ts>=tr['entry_t'])&(ts<=tr['exit_t']);ix=np.flatnonzero(opened)
  open_n[ix]+=1;notional[ix]+=tr['size'];realized[ts>tr['exit_t']]+=tr['pnl']
  if price_times is not None:missing_marks+=sum(int(t) not in price_times[tr['coin']] for t in ts[ix])
  exposure_hours+=tr['size']*(tr['exit_t']-tr['entry_t'])/3600000
  times,rates,cumul=funding[tr['coin']]
  lo=np.searchsorted(times,tr['entry_t'],side='left');hi=np.searchsorted(times,ts[ix],side='right')
  n=hi-lo;avg=np.divide(cumul[hi]-cumul[lo],n,out=np.zeros(len(n)),where=n>0)
  fund[ix]+=tr['dir']*avg*(ts[ix]-tr['entry_t'])/3600000*tr['size']
 assert np.array_equal(open_n,np.array([b['n_pos'] for b in basket])),'open count differs'
 assert np.max(np.abs(cap-realized))<=.00501,'realized balance differs'
 # Conservative liquidation-cost reserve on all still-open positions. Funding
 # follows native mean-rate*hours accounting. Proxy at candle closes, not ticks.
 equity=cap+ur-notional*cost/10000-fund
 equity=np.r_[500,equity,end]
 dd=(equity/np.maximum.accumulate(equity)-1)*100
 gross_equity=np.r_[500,cap+ur,end]
 return {'open_position_bars_without_price':missing_marks,'dd_realized_native':r['max_dd_pct'],'dd_mtm4h_gross_proxy':float(np.min((gross_equity/np.maximum.accumulate(gross_equity)-1)*100)),
 'dd_mtm4h_cost_funding_proxy':float(dd.min()),'minimum_equity_proxy':float(equity.min()),'end_capital':end,'max_open_positions':int(open_n.max()),
 'mean_open_notional':float(notional.mean()),'max_open_notional':float(notional.max()),'notional_hours':exposure_hours,'n_trades':len(trades)}

def main():
 import backtests.backtest_genetic as genetic
 genetic.DATA_DIR='/tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot'
 data=genetic.load_3y_candles();price_times={s:{int(c['t']) for c in rows} for s,rows in data.items()}
 funding={}
 with sqlite3.connect(FUND.as_uri()+'?mode=ro',uri=True) as db:
  for s, in db.execute('select distinct symbol from funding'):
   rows=db.execute('select ts,funding_rate from funding where symbol=? order by ts',(s,)).fetchall()
   times=np.array([x[0] for x in rows],dtype=np.int64);rates=np.array([x[1] for x in rows]);funding[s]=(times,rates,np.r_[0,np.cumsum(rates)])
 output={'description':'Research checks; risk is candle-close proxy, not guaranteed max loss. No EUR subscription deducted from USD capital.','runs':[],'baseline_checks':[]}
 exits=read('/tmp/alfred-research-exits-20260917/docs/exit_extension_results.json')['runs']
 dates=['2024-09-16T12:00','2025-03-16T12:00','2025-09-16T12:00','2026-03-16T12:00']
 for slip in [4,6]:
  for window in range(4):
   base=read(ROOT/f'results/baseline_s{slip}_w{window}.json.gz')
   group=[]
   for row in exits:
    if row['start']==dates[window] and row['slip']==slip:group.append(('exits',row['variant'],row))
   for variant in ['baseline','funding_rank']:
    group.append(('entries',variant,read(f'/tmp/alfred-research-entries-20260917/docs/entry_rank_data/slip{slip}_window{window}_{variant}.json.gz')))
   for cap in [0,2,3]:
    group.append(('portfolio',f'cap{cap}',read(f'/tmp/alfred-research-portfolio-20260917/docs/portfolio_results/slip{slip}_semester{window+1}_cap{cap}.json.gz')))
   for family,variant,result in group:
    isbase=variant in ['baseline','cap0']
    if isbase:
     assert abs(result['end_capital']-base['end_capital'])<1e-9,(family,slip,window)
     assert result['trades']==base['trades'],('ledger mismatch',family,slip,window)
     output['baseline_checks'].append({'family':family,'slip':slip,'window':window,'ledger_identical':True})
    item={'family':family,'variant':variant,'slip':slip,'window':window,'metrics':metrics(result,9+slip,funding,price_times)}
    if not isbase:item['decomposition']=decompose(base,result)
    output['runs'].append(item)
 (ROOT/'validation.json').write_text(json.dumps(output,indent=2)+'\n')
 print('Verified:',len(output['baseline_checks']),'identical baseline ledgers;',len(output['runs']),'run accountings and risk paths')
 for r in output['runs']:
  if r['family']=='exits' and r['variant']!='null':print(r['slip'],r['window'],r['variant'],r['metrics'],r.get('decomposition',{}))

if __name__=='__main__':main()
