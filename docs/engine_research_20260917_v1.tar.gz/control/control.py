from pathlib import Path
import json,gzip,hashlib,sqlite3,time
from datetime import datetime,timezone
import numpy as np
from alfred.settings import DEFAULT_PARAMS as p
import backtests.backtest_genetic as genetic
import backtests.backtest_rolling as engine
from backtests.backtest_sector import compute_sector_features
from backtests.fingerprint import config_hash
source=Path('/tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot')
out=Path('/tmp/alfred-research-control-20260917/results');out.mkdir(exist_ok=True)
genetic.DATA_DIR=str(source);engine.DATA_DIR=str(source)
data=genetic.load_3y_candles();oi=engine.load_oi();features=genetic.build_features(data);sectors=compute_sector_features(features,data);dxy=engine.load_dxy()
funding={}
with sqlite3.connect('file:/tmp/alfred-cascade-20260917/funding_history.db?mode=ro',uri=True) as db:
 for symbol in p.trade_symbols:
  rows=db.execute('select ts,funding_rate from funding where symbol=? order by ts',(symbol,)).fetchall()
  funding[symbol]=(np.array([r[0] for r in rows],dtype=np.int64),np.array([r[1] for r in rows],dtype=float))
def ms(s):return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp()*1000)
dates=['2024-09-16T12:00','2025-03-16T12:00','2025-09-16T12:00','2026-03-16T12:00','2026-09-16T12:00']
summary=[]
for slip in [4,6]:
 engine.BACKTEST_SLIPPAGE_BPS=slip;engine.COST=engine.TAKER_FEE_BPS+slip;engine._P=p
 for i,(start,end) in enumerate(zip(dates,dates[1:])):
  ts=time.monotonic()
  result=engine.run_window(features,data,sectors,dxy,ms(start),ms(end)-1,start_capital=500,oi_data=oi,funding_data=funding,apply_adaptive_modulator=True,aligned=True,margin_check=True,mfe_on_close=True,realistic_trail_booking=True)
  assert all(t['entry_t']<=t['exit_t'] and t['entry_t']<ms(end) for t in result['trades'])
  assert abs(result['end_capital']-(500+sum(t['pnl'] for t in result['trades'])))<1e-7
  raw=json.dumps(result,sort_keys=True,default=lambda x:x.item() if hasattr(x,'item') else str(x)).encode()
  name=f'baseline_s{slip}_w{i}.json.gz'
  with gzip.open(out/name,'wb') as f:f.write(raw)
  item=dict(slip=slip,window=i,start=start,end=end,capital=result['end_capital'],dd=result['max_dd_pct'],n=result['n_trades'],file=name,sha256=hashlib.sha256(raw).hexdigest(),config_hash=config_hash(p))
  summary.append(item);(out/'summary.json').write_text(json.dumps(summary,indent=2))
  print(item,'seconds',round(time.monotonic()-ts,1),flush=True)
