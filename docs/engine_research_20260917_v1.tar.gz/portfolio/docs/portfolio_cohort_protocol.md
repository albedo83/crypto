# Protocole figé avant exécution — 2026-09-17
Hypothèse : un plafond du nombre de positions de même stratégie et direction réduit la répétition du même pari idiosyncratique. Aucun changement ranking, tailles, sorties, paramètres macro.
Variantes exhaustives : témoin plafond0 (inactif), plafond2, plafond3. Aucun seuil supplémentaire après résultats. Toutes stratégies également concernées.
Capital initial500 à chaque semestre, quatre semestres disjoints 2024-09-16T12:00 → 2026-09-16T12:00. Coûts13/15bps + funding historique. Tous flags réalistes alignés. Données historiques réutilisées, pas OOS neuf.
Critère de candidat à validation prospective (pas déploiement) : PNL supérieur au témoin dans les4semestres à chacun des2coûts, DD MTM4h pas dégradé >2points, aucun DD MTM au-delà50%. Sinon hypothèse non validée. Exposition, ordres écartés et toutes fenêtres publiés.
Limites : bougies4h, DD MTM proxy sans funding/coûts de liquidation latents, données OI TON périmées depuis juin2026, fenêtres déjà explorées. Pas d'extrapolation au rendementLive.

Amendement mécanique après première exécution, sans retouche des variantes : contrôle nextopen<=fin avant entrée, pour interdire entry_t>exit_t aux bornes. Premiers résultats archivésinvalid_boundary.24runs identiques relancés.
