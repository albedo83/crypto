# Plafond par stratégie et direction — recherche du17septembre2026

Verdict : aucune variante ne satisfait le critère préenregistré. Aucun changement Live proposé. Capital initial500USD par semestre, résultats dans la monnaie du moteur; pas de conversionEUR ni de prévision.

Deux variantes fixées avant résultats : maximum2 ou3 positions simultanées partageant stratégie et direction, au lieu de la limite actuelle globale par direction4. Tailles, classement et sorties inchangés. Le cap2 gagne1/4 semestres, le cap3 gagne3/4 aux deux coûts.

|Coût hors funding|Semestre|Plafond|GainUSD|Δgain vs témoin|DD clôturé%|DD MTM proxy%|Exposition brute moyenne/capital|Trades|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|13bps|2024-09-16 → 2025-03-16|témoin|311.02|+0.00|-37.48|-36.35|0.791|294|
|13bps|2024-09-16 → 2025-03-16|2|181.14|-129.88|-26.55|-27.32|0.649|262|
|13bps|2024-09-16 → 2025-03-16|3|397.20|+86.18|-37.48|-36.35|0.737|282|
|13bps|2025-03-16 → 2025-09-16|témoin|207.05|+0.00|-31.49|-32.12|0.743|267|
|13bps|2025-03-16 → 2025-09-16|2|129.32|-77.73|-41.11|-41.59|0.659|243|
|13bps|2025-03-16 → 2025-09-16|3|220.21|+13.16|-32.31|-32.56|0.719|263|
|13bps|2025-09-16 → 2026-03-16|témoin|1243.58|+0.00|-23.26|-22.73|0.711|264|
|13bps|2025-09-16 → 2026-03-16|2|824.75|-418.82|-22.20|-21.88|0.657|244|
|13bps|2025-09-16 → 2026-03-16|3|1130.43|-113.14|-22.95|-23.53|0.710|261|
|13bps|2026-03-16 → 2026-09-16|témoin|24.06|+0.00|-32.62|-32.73|0.925|315|
|13bps|2026-03-16 → 2026-09-16|2|141.42|+117.35|-25.14|-25.82|0.794|285|
|13bps|2026-03-16 → 2026-09-16|3|65.96|+41.90|-26.75|-26.80|0.879|304|
|15bps|2024-09-16 → 2025-03-16|témoin|297.27|+0.00|-37.72|-36.61|0.791|294|
|15bps|2024-09-16 → 2025-03-16|2|170.79|-126.47|-26.81|-27.58|0.649|262|
|15bps|2024-09-16 → 2025-03-16|3|382.63|+85.36|-37.72|-36.61|0.738|282|
|15bps|2025-03-16 → 2025-09-16|témoin|195.95|+0.00|-31.80|-32.74|0.743|267|
|15bps|2025-03-16 → 2025-09-16|2|120.29|-75.66|-41.43|-41.89|0.659|243|
|15bps|2025-03-16 → 2025-09-16|3|209.10|+13.15|-32.61|-32.85|0.719|263|
|15bps|2025-09-16 → 2026-03-16|témoin|1216.85|+0.00|-23.36|-22.78|0.711|264|
|15bps|2025-09-16 → 2026-03-16|2|805.90|-410.95|-22.34|-21.93|0.657|244|
|15bps|2025-09-16 → 2026-03-16|3|1105.68|-111.16|-23.10|-23.57|0.710|261|
|15bps|2026-03-16 → 2026-09-16|témoin|14.39|+0.00|-33.14|-33.24|0.925|315|
|15bps|2026-03-16 → 2026-09-16|2|130.73|+116.34|-25.29|-25.91|0.794|285|
|15bps|2026-03-16 → 2026-09-16|3|55.90|+41.52|-27.00|-26.97|0.879|304|

Le cap3 réduit modestement l’exposition et améliore le semestre récent (+41.90USD à13bps), mais perd113.14USD sur septembre2025–mars2026. Son solde sur les4 expériences indépendantes vaut+28.10USD : ce n’est pas une trajectoire composée. Le cap2 diminue plus l’exposition mais le DD empire sur le deuxième semestre : moins de positions ne garantit pas moins de perte.

Validation : 4 tests unitaires; identité complète du témoin au moteur production sur294trades et la série portefeuille du premier semestre;24ledgers/6568trades revérifiés par somme comptable, tailles finies positives et plafond effectivement respecté. Toutes les variantes et résultats sont conservés.

Limites : données déjà utilisées pour la recherche; pas de période neuve horséchantillon. Univers actuel non pointintime; bougies4h, aucune reconstitution des ticksLive. Funding selon moyenne des taux disponibles multipliée par durée (modèle natif), pas somme exacte des versements. OI TON périmé depuis2026-06-15. DD clôturé ignore pertes ouvertes et finalMTM; proxy MTM utilise capital+basket_unreal avant sorties, sans coûts/funding latents et sans excursion intrabougie. Le proxy peut donc être moins profond que le DD clôturé. Exposition rapportée au capital clôturé, pas équité instantanée. Compteurs de skips sont occurrences de candidats, pas occasions uniques.

Reproduction : `/home/crypto/.venv/bin/python3 run_portfolio.py`, puis `verify_baseline.py`, `verify_ledgers.py`, `report_portfolio.py`. Sources figées snapshot prixOI et DBfunding listés dans le runner. Production inchangée; étude seule, aucune version runtime incrémentée.
