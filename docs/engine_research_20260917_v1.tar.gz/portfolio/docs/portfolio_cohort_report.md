# Plafond par stratégie et direction — recherche du17septembre2026

Verdict : aucune variante ne satisfait le critère préenregistré. Aucun changement Live proposé. Capital initial500USD par semestre, résultats dans la monnaie du moteur; pas de conversionEUR ni de prévision.

Deux variantes fixées avant résultats : maximum2 ou3 positions simultanées partageant stratégie et direction, au lieu de la limite actuelle globale par direction4. Tailles, classement et sorties inchangés. Le cap2 gagne1/4 semestres, le cap3 gagne3/4 aux deux coûts.

|Coût hors funding|Semestre|Plafond|GainUSD|Δgain vs témoin|DD clôturé%|DD MTM proxy%|Exposition brute moyenne/capital|Trades|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|13bps|2024-09-16 → 2025-03-16|témoin|311.33|+0.00|-37.48|-36.35|0.791|293|
|13bps|2024-09-16 → 2025-03-16|2|181.40|-129.93|-26.55|-27.32|0.649|261|
|13bps|2024-09-16 → 2025-03-16|3|397.55|+86.22|-37.48|-36.35|0.737|281|
|13bps|2025-03-16 → 2025-09-16|témoin|207.25|+0.00|-31.49|-32.12|0.743|266|
|13bps|2025-03-16 → 2025-09-16|2|129.73|-77.53|-41.11|-41.59|0.659|241|
|13bps|2025-03-16 → 2025-09-16|3|220.42|+13.16|-32.31|-32.56|0.719|262|
|13bps|2025-09-16 → 2026-03-16|témoin|1243.58|+0.00|-23.26|-22.73|0.711|264|
|13bps|2025-09-16 → 2026-03-16|2|824.75|-418.82|-22.20|-21.88|0.657|244|
|13bps|2025-09-16 → 2026-03-16|3|1130.43|-113.14|-22.95|-23.53|0.710|261|
|13bps|2026-03-16 → 2026-09-16|témoin|24.06|+0.00|-32.62|-32.73|0.925|315|
|13bps|2026-03-16 → 2026-09-16|2|141.42|+117.35|-25.14|-25.82|0.794|285|
|13bps|2026-03-16 → 2026-09-16|3|65.96|+41.90|-26.75|-26.80|0.879|304|
|15bps|2024-09-16 → 2025-03-16|témoin|297.62|+0.00|-37.72|-36.61|0.791|293|
|15bps|2024-09-16 → 2025-03-16|2|171.09|-126.53|-26.81|-27.58|0.649|261|
|15bps|2024-09-16 → 2025-03-16|3|383.02|+85.40|-37.72|-36.61|0.738|281|
|15bps|2025-03-16 → 2025-09-16|témoin|196.19|+0.00|-31.80|-32.74|0.743|266|
|15bps|2025-03-16 → 2025-09-16|2|120.77|-75.42|-41.43|-41.89|0.659|241|
|15bps|2025-03-16 → 2025-09-16|3|209.35|+13.15|-32.61|-32.85|0.719|262|
|15bps|2025-09-16 → 2026-03-16|témoin|1216.85|+0.00|-23.36|-22.78|0.711|264|
|15bps|2025-09-16 → 2026-03-16|2|805.90|-410.95|-22.34|-21.93|0.657|244|
|15bps|2025-09-16 → 2026-03-16|3|1105.68|-111.16|-23.10|-23.57|0.710|261|
|15bps|2026-03-16 → 2026-09-16|témoin|14.39|+0.00|-33.14|-33.24|0.925|315|
|15bps|2026-03-16 → 2026-09-16|2|130.73|+116.34|-25.29|-25.91|0.794|285|
|15bps|2026-03-16 → 2026-09-16|3|55.90|+41.52|-27.00|-26.97|0.879|304|

Le cap3 réduit modestement l’exposition et améliore le semestre récent (voir tableau à13bps), mais perd du PNL sur septembre2025–mars2026. Ces quatre expériences indépendantes ne constituent pas une trajectoire composée. Le cap2 diminue plus l’exposition mais le DD empire sur le deuxième semestre : moins de positions ne garantit pas moins de perte.

Validation : 4 tests unitaires; identité complète du témoin au moteur production avec correction de borne finale sur les trades et la série portefeuille du premier semestre;24ledgers revérifiés par somme comptable, tailles finies positives et plafond effectivement respecté. Toutes les variantes et résultats sont conservés.

Limites : données déjà utilisées pour la recherche; pas de période neuve horséchantillon. Univers actuel non pointintime; bougies4h, aucune reconstitution des ticksLive. Funding selon moyenne des taux disponibles multipliée par durée (modèle natif), pas somme exacte des versements. OI TON périmé depuis2026-06-15. DD clôturé ignore pertes ouvertes et finalMTM; proxy MTM utilise capital+basket_unreal avant sorties, sans coûts/funding latents et sans excursion intrabougie. Le proxy peut donc être moins profond que le DD clôturé. Exposition rapportée au capital clôturé, pas équité instantanée. Compteurs de skips sont occurrences de candidats, pas occasions uniques.

Reproduction : `/home/crypto/.venv/bin/python3 run_portfolio.py`, puis `verify_baseline.py`, `verify_ledgers.py`, `report_portfolio.py`. Sources figées snapshot prixOI et DBfunding listés dans le runner. Production inchangée; étude seule, aucune version runtime incrémentée. Premiers24runs invalidés par une entrée hors borne (entry_t>exit_t), archivés dans portfolio_results_invalid_boundary; correction chronologique uniforme et relance des24runs sans retouche des variantes. Contrôle entry_t<=exit_t et entry_t<borne finale exécuté sur chaque trade.
