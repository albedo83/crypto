import json, sqlite3, hashlib, gzip, time
from pathlib import Path
import numpy as np
from alfred.settings import DEFAULT_PARAMS
import backtests.backtest_genetic as genetic
import backtests.backtest_rolling as engine
from backtests.backtest_sector import compute_sector_features
from backtests.recheck_macro_2026_09 import ms
from backtests.fingerprint import config_hash
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'docs/portfolio_results';OUT.mkdir(exist_ok=True)
SNAP=Path('/tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot')
genetic.DATA_DIR=engine.DATA_DIR=str(SNAP)
data=genetic.load_3y_candles();oi=engine.load_oi();features=genetic.build_features(data);sectors=compute_sector_features(features,data);dxy=engine.load_dxy()
db=sqlite3.connect('file:/tmp/alfred-cascade-20260917/funding_history.db?mode=ro',uri=True)
funding={}
for symbol in DEFAULT_PARAMS.trade_symbols:
 rows=db.execute('select ts,funding_rate from funding where symbol=? order by ts',(symbol,)).fetchall()
 funding[symbol]=(np.array([r[0] for r in rows],dtype=np.int64),np.array([r[1] for r in rows],dtype=np.float64))
db.close()
dates=['2024-09-16T12:00','2025-03-16T12:00','2025-09-16T12:00','2026-03-16T12:00','2026-09-16T12:00']
out={'protocol_sha256':hashlib.sha256((ROOT/'docs/portfolio_cohort_protocol.md').read_bytes()).hexdigest(),'params_hash':config_hash(DEFAULT_PARAMS),'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SNAP.glob('*.json')},'funding_hashes':{s:hashlib.sha256(v[0].tobytes()+v[1].tobytes()).hexdigest() for s,v in funding.items()},'runs':[]}

import importlib.util
spec=importlib.util.spec_from_file_location("original_engine", "/home/crypto/backtests/backtest_rolling.py")
original=importlib.util.module_from_spec(spec)
source=Path("/home/crypto/backtests/backtest_rolling.py").read_text()
needle='            entry = data[coin][idx_f + 1]["o"]\n'
assert source.count(needle)==1
source=source.replace(needle,'            if data[coin][idx_f + 1]["t"] > end_ts_ms:\n                continue\n'+needle)
exec(compile(source,spec.origin,"exec"), original.__dict__)
original.DATA_DIR=str(SNAP);original.COST=13;original.BACKTEST_SLIPPAGE_BPS=4
r=original.run_window(features,data,sectors,dxy,start_ts_ms=ms(dates[0]),end_ts_ms=ms(dates[1])-1,start_capital=500,oi_data=oi,funding_data=funding,apply_adaptive_modulator=True,aligned=True,margin_check=True,mfe_on_close=True,realistic_trail_booking=True)
with gzip.open(OUT/'slip4_semester1_cap0.json.gz','rt') as f:b=json.load(f)
assert r['trades']==b['trades']
for k in ('end_capital','max_dd_pct','n_trades','pnl'):assert r[k]==b[k],k
for a,c in zip(r['basket_timeseries'],b['basket_timeseries']):
 for k,v in a.items():assert c[k]==v,k
report={'test':'original engine + boundary correction vs patched cap0 full ledger + basket original keys','pass':True,'n_trades':r['n_trades'],'end_capital':r['end_capital']}
(OUT/'baseline_identity.json').write_text(json.dumps(report,indent=2));print(report)
