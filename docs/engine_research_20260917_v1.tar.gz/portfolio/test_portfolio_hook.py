import unittest
from portfolio_hook import cohort_blocked
class CohortTests(unittest.TestCase):
 def test_empty(self):
  self.assertFalse(cohort_blocked({'strat':'S1','dir':1},{},2))
 def test_cap_and_direction(self):
  p={'A':{'strat':'S5','dir':-1},'B':{'strat':'S5','dir':-1},'C':{'strat':'S5','dir':1}}
  self.assertTrue(cohort_blocked({'strat':'S5','dir':-1},p,2))
  self.assertFalse(cohort_blocked({'strat':'S5','dir':1},p,2))
  self.assertFalse(cohort_blocked({'strat':'S1','dir':-1},p,2))
  self.assertFalse(cohort_blocked({'strat':'S5','dir':-1},p,3))
 def test_disabled_and_pure(self):
  p={'A':{'strat':'S5','dir':-1},'B':{'strat':'S5','dir':-1}}
  import copy
  before=copy.deepcopy(p)
  self.assertFalse(cohort_blocked({'strat':'S5','dir':-1},p,0))
  self.assertEqual(p,before)
 def test_invalid(self):
  with self.assertRaises(ValueError):cohort_blocked({'strat':'S5','dir':-1},{},-1)
if __name__=='__main__':unittest.main()
