import json, sqlite3, hashlib, gzip, time
from pathlib import Path
import numpy as np
from alfred.settings import DEFAULT_PARAMS
import backtests.backtest_genetic as genetic
import backtests.backtest_rolling as engine
from backtests.backtest_sector import compute_sector_features
from backtests.recheck_macro_2026_09 import ms
from backtests.fingerprint import config_hash
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'docs/portfolio_results';OUT.mkdir(exist_ok=True)
SNAP=Path('/tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot')
genetic.DATA_DIR=engine.DATA_DIR=str(SNAP)
data=genetic.load_3y_candles();oi=engine.load_oi();features=genetic.build_features(data);sectors=compute_sector_features(features,data);dxy=engine.load_dxy()
db=sqlite3.connect('file:/tmp/alfred-cascade-20260917/funding_history.db?mode=ro',uri=True)
funding={}
for symbol in DEFAULT_PARAMS.trade_symbols:
 rows=db.execute('select ts,funding_rate from funding where symbol=? order by ts',(symbol,)).fetchall()
 funding[symbol]=(np.array([r[0] for r in rows],dtype=np.int64),np.array([r[1] for r in rows],dtype=np.float64))
db.close()
dates=['2024-09-16T12:00','2025-03-16T12:00','2025-09-16T12:00','2026-03-16T12:00','2026-09-16T12:00']
out={'protocol_sha256':hashlib.sha256((ROOT/'docs/portfolio_cohort_protocol.md').read_bytes()).hexdigest(),'params_hash':config_hash(DEFAULT_PARAMS),'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SNAP.glob('*.json')},'funding_hashes':{s:hashlib.sha256(v[0].tobytes()+v[1].tobytes()).hexdigest() for s,v in funding.items()},'runs':[]}
for slip in (4,6):
 engine.BACKTEST_SLIPPAGE_BPS=slip;engine.COST=engine.TAKER_FEE_BPS+slip;engine._P=DEFAULT_PARAMS
 assert engine.COST==9+slip
 for i,(start,end) in enumerate(zip(dates,dates[1:]),1):
  for cap in (0,2,3):
   skips=[];t0=time.monotonic()
   r=engine.run_window(features,data,sectors,dxy,start_ts_ms=ms(start),end_ts_ms=ms(end)-1,start_capital=500,oi_data=oi,funding_data=funding,apply_adaptive_modulator=True,aligned=True,margin_check=True,mfe_on_close=True,realistic_trail_booking=True,cohort_cap=cap,cohort_skips=skips)
   name=f'slip{slip}_semester{i}_cap{cap}'
   with gzip.open(OUT/(name+'.json.gz'),'wt') as f:json.dump(r,f)
   with gzip.open(OUT/(name+'_skips.json.gz'),'wt') as f:json.dump(skips,f)
   eq=np.array([500]+[v['capital']+v['basket_unreal'] for v in r['basket_timeseries']]+[r['end_capital']])
   dd=float(np.min((eq/np.maximum.accumulate(eq)-1)*100))
   gross=[v['gross_notional']/v['capital'] for v in r['basket_timeseries'] if v['capital']>0]
   item={'name':name,'slip':slip,'cap':cap,'semester':i,'start':start,'end':end,'end_capital':r['end_capital'],'pnl':r['pnl'],'dd_closed':r['max_dd_pct'],'dd_mtm_proxy':dd,'n':r['n_trades'],'skips':len(skips),'avg_gross_over_closed_capital':float(np.mean(gross)),'max_gross_over_closed_capital':float(np.max(gross)),'mean_positions':float(np.mean([v['n_pos'] for v in r['basket_timeseries']])),'ledger_sha256':hashlib.sha256((OUT/(name+'.json.gz')).read_bytes()).hexdigest()}
   out['runs'].append(item);(OUT/'summary.json').write_text(json.dumps(out,indent=2))
   print(name,json.dumps(item),f'{time.monotonic()-t0:.1f}s',flush=True)
