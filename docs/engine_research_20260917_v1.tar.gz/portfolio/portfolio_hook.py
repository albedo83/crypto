def cohort_blocked(candidate, positions, cap):
    if cap == 0:
        return False
    if not isinstance(cap, int) or cap < 0:
        raise ValueError('cap must be a nonnegative integer')
    return sum(p['strat'] == candidate['strat'] and p['dir'] == candidate['dir']
               for p in positions.values()) >= cap
