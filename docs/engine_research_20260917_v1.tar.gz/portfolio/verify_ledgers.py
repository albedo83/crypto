import gzip,json,math
from pathlib import Path
from collections import defaultdict
root=Path(__file__).parent/'docs/portfolio_results'
s=json.loads((root/'summary.json').read_text());verified=[]
for item in s['runs']:
 with gzip.open(root/(item['name']+'.json.gz'),'rt') as f:r=json.load(f)
 assert abs(500+sum(t['pnl'] for t in r['trades'])-r['end_capital'])<1e-8
 assert len(r['trades'])==item['n']
 from backtests.recheck_macro_2026_09 import ms
 assert all(t['entry_t'] <= t['exit_t'] and t['entry_t'] < ms(item['end']) for t in r['trades'])
 assert all(math.isfinite(t['pnl']) and t['size']>0 for t in r['trades'])
 maxcohort=0
 for t in r['trades']:
  at=t['entry_t']-14400000
  n=sum(p['strat']==t['strat'] and p['dir']==t['dir'] and p['entry_t']<=t['entry_t'] and p['exit_t']>at for p in r['trades'])
  maxcohort=max(maxcohort,n)
 if item['cap']:assert maxcohort<=item['cap'],(item['name'],maxcohort)
 verified.append({'run':item['name'],'trades':len(r['trades']),'max_cohort':maxcohort,'pass':True})
(root/'ledger_verification.json').write_text(json.dumps(verified,indent=2));print('Verified',len(verified),'ledgers,',sum(v['trades'] for v in verified),'trades')
