import unittest
import numpy as np
from backtests.research_entry_funding_rank import FundingRank,HOUR
class RankTests(unittest.TestCase):
    def test_future_excluded(self):
        ts=30*HOUR;t=np.array([7,8,9,30,31])*HOUR
        a=FundingRank({'A':(t,np.array([.1,.2,.3,999.,999.]))})
        b=FundingRank({'A':(t,np.array([.1,.2,.3,-999.,-999.]))})
        c={'coin':'A','dir':1}
        self.assertAlmostEqual(a.cost(c,ts),.2);self.assertEqual(a.cost(c,ts),b.cost(c,ts))
    def test_direction(self):
        rank=FundingRank({'A':(np.array([7,8,9])*HOUR,np.array([.1,.2,.3]))})
        self.assertAlmostEqual(rank.cost({'coin':'A','dir':-1},30*HOUR),-.2)
    def test_priority_and_ties(self):
        c=[{'coin':'A','dir':1,'z':6,'strength':1},{'coin':'B','dir':1,'z':3,'strength':2},{'coin':'C','dir':1,'z':3,'strength':1}]
        r=FundingRank({});self.assertEqual(r(c,30*HOUR),c)
    def test_observed_cost_breaks_tie_and_preserves_population(self):
        series=lambda rate:(np.array([7,8,9])*HOUR,np.array([rate]*3))
        r=FundingRank({"A":series(.2),"B":series(.1)})
        c=[{"coin":"A","dir":1,"z":3,"strength":9},{"coin":"B","dir":1,"z":3,"strength":1}]
        self.assertEqual(r(c,30*HOUR),list(reversed(c)))
        self.assertEqual(len(r(c,30*HOUR)),len(c))
    def test_sparse_neutral(self):
        r=FundingRank({'A':(np.array([29])*HOUR,np.array([1.]))})
        self.assertEqual(r.cost({'coin':'A','dir':1},30*HOUR),0)
if __name__=='__main__':unittest.main()
