"""One preregistered funding-cost candidate ranking; isolated research only."""
from pathlib import Path
import sys, json, sqlite3, hashlib, gzip
from collections import defaultdict
from datetime import datetime, timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from alfred.settings import DEFAULT_PARAMS
import backtests.backtest_genetic as genetic
import backtests.backtest_rolling as engine
from backtests.backtest_sector import compute_sector_features
from backtests.fingerprint import config_hash
ROOT=Path(__file__).resolve().parents[1]
SNAP=Path('/tmp/alfred-next-20260917/backtests/output/macro_recheck_snapshot')
FUND=Path('/tmp/alfred-cascade-20260917/funding_history.db')
HOUR=3600000

def ms(s): return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp()*1000)

class FundingRank:
    def __init__(self,funding):
        self.funding=funding
        self.counts=defaultdict(int)
    def cost(self,c,ts):
        self.counts['candidate_evaluations']+=1
        series=self.funding.get(c['coin'])
        if series is None:
            self.counts['fallback_missing']+=1
            return 0.
        times,rates=series
        lo=np.searchsorted(times,ts-24*HOUR,side='left')
        hi=np.searchsorted(times,ts,side='left')
        if hi-lo<3:
            self.counts['fallback_sparse']+=1
            return 0.
        assert times[lo]>=ts-24*HOUR and times[hi-1]<ts
        return c['dir']*float(rates[lo:hi].mean())
    def __call__(self,candidates,ts):
        self.counts['scans']+=1
        ordered=sorted(candidates,key=lambda c:(-c['z'],self.cost(c,ts),-c['strength']))
        if ordered!=candidates:self.counts['reordered_scans']+=1
        return ordered

def main():
    genetic.DATA_DIR=engine.DATA_DIR=str(SNAP)
    data=genetic.load_3y_candles(); oi=engine.load_oi()
    con=sqlite3.connect(FUND.as_uri()+'?mode=ro',uri=True)
    funding={}
    for coin in DEFAULT_PARAMS.trade_symbols:
        rows=con.execute('SELECT ts,funding_rate FROM funding WHERE symbol=? ORDER BY ts',(coin,)).fetchall()
        assert rows,coin
        funding[coin]=(np.array([r[0] for r in rows],dtype=np.int64),np.array([r[1] for r in rows],dtype=np.float64))
    con.close()
    features=genetic.build_features(data); sectors=compute_sector_features(features,data);dxy=engine.load_dxy()
    outdir=ROOT/'docs/entry_rank_data';outdir.mkdir(exist_ok=True)
    output={'protocol':'docs/entry_funding_rank_protocol.md','base_commit':'e299fbdd7a0911547b088404579822a4bda439b8',
        'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SNAP.glob('*.json'))},
        'funding_sha256':{s:hashlib.sha256(t.tobytes()+r.tobytes()).hexdigest() for s,(t,r) in funding.items()},
        'config_hash':config_hash(DEFAULT_PARAMS),'runs':[]}
    dates=['2024-09-16T12:00','2025-03-16T12:00','2025-09-16T12:00','2026-03-16T12:00','2026-09-16T12:00']
    for slip in (4.,6.):
        engine.BACKTEST_SLIPPAGE_BPS=slip;engine.COST=engine.TAKER_FEE_BPS+slip
        assert engine.COST==9+slip
        for i,(start,end) in enumerate(zip(dates,dates[1:])):
            for variant in ('baseline','funding_rank'):
                rank=FundingRank(funding) if variant=='funding_rank' else None
                engine._P=DEFAULT_PARAMS
                result=engine.run_window(features,data,sectors,dxy,start_ts_ms=ms(start),end_ts_ms=ms(end)-1,
                    start_capital=500,oi_data=oi,funding_data=funding,apply_adaptive_modulator=True,
                    aligned=True,margin_check=True,mfe_on_close=True,realistic_trail_booking=True,candidate_rank_fn=rank)
                name=f'slip{int(slip)}_window{i}_{variant}'
                with gzip.open(outdir/(name+'.json.gz'),'wt') as f:json.dump(result,f,default=lambda x:x.item() if isinstance(x,np.generic) else list(x))
                trades=result['trades']; pnls=[t['pnl'] for t in trades]
                per=defaultdict(lambda:{'n':0,'pnl':0.})
                for t in trades:
                    key=f"{t['strat']}:{t['dir']}";per[key]['n']+=1;per[key]['pnl']+=t['pnl']
                run={'id':name,'slippage_bps':slip,'cost_bps':engine.COST,'start':start,'end':end,'variant':variant,
                    'end_capital':result['end_capital'],'max_dd_pct':result['max_dd_pct'],'n_trades':len(trades),
                    'positive_pnl':sum(p for p in pnls if p>0),'negative_pnl':sum(p for p in pnls if p<0),
                    'five_best_pnl':sum(sorted(pnls,reverse=True)[:5]),'per_strategy_direction':dict(per),
                    'ranking_counts':dict(rank.counts) if rank else {},'ledger':str(outdir/(name+'.json.gz'))}
                output['runs'].append(run)
                (ROOT/'docs/entry_funding_rank_results.json').write_text(json.dumps(output,indent=2))
                print(name,round(run['end_capital'],2),round(run['max_dd_pct'],2),len(trades),run['ranking_counts'],flush=True)
if __name__=='__main__':main()
