# Arbitrage des candidats par coût de funding observé — REFUSÉ

Recherche isolée du 17 septembre 2026. Une hypothèse, une variante préfixée, 16 simulations. Aucun déploiement.

Les signaux et la priorité z sont conservés. À priorité égale, sélectionner le candidat dont le funding signé moyen déjà observé sur 24 h coûte le moins ; force comme départage. Ce n’est pas un filtre de crowding ni un seuil optimisé.

Capital initial **500 USD/USDC nominaux** par semestre. Les montants ne sont pas convertis en EUR et excluent abonnement, API et serveur.

| Semestre | Coût hors funding | Capital base | Capital variante | Δ USD | DD base | DD variante | Trades base/variante |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2024-09-16 → 2025-03-16 | 13 bps | 811.33 | 607.43 | -203.90 | -37.48% | -37.48% | 293/297 |
| 2025-03-16 → 2025-09-16 | 13 bps | 707.25 | 725.94 | +18.69 | -31.49% | -40.00% | 266/266 |
| 2025-09-16 → 2026-03-16 | 13 bps | 1743.58 | 1744.04 | +0.47 | -23.26% | -23.68% | 264/262 |
| 2026-03-16 → 2026-09-16 | 13 bps | 524.06 | 403.91 | -120.16 | -32.62% | -38.76% | 315/316 |
| 2024-09-16 → 2025-03-16 | 15 bps | 797.62 | 596.97 | -200.65 | -37.72% | -37.72% | 293/297 |
| 2025-03-16 → 2025-09-16 | 15 bps | 696.19 | 714.60 | +18.40 | -31.80% | -40.27% | 266/266 |
| 2025-09-16 → 2026-03-16 | 15 bps | 1716.85 | 1717.51 | +0.66 | -23.36% | -23.83% | 264/262 |
| 2026-03-16 → 2026-09-16 | 15 bps | 514.39 | 396.38 | -118.00 | -33.14% | -39.25% | 315/316 |

**Échec du critère préfixé** : seulement 2/4 semestres positifs aux deux coûts, dont un quasi nul ; pertes additionnelles >25 USD et drawdown aggravé >2 points. Pas de tuning après résultat.

## Contributions et concentration (coût 13 bps)

| Semestre / méthode | Gains cumulés | Pertes cumulées | Cinq meilleurs trades | Funding net payé |
|---|---:|---:|---:|---:|
| 2024-09-16 / baseline | 2138.86 | -1827.53 | 248.63 | 25.14 |
| 2024-09-16 / funding_rank | 1867.59 | -1760.17 | 258.67 | 12.10 |
| 2025-03-16 / baseline | 1873.74 | -1666.49 | 389.88 | 2.58 |
| 2025-03-16 / funding_rank | 2108.20 | -1882.26 | 482.38 | -3.03 |
| 2025-09-16 / baseline | 2806.86 | -1563.29 | 416.82 | -19.19 |
| 2025-09-16 / funding_rank | 2817.57 | -1573.53 | 401.03 | -15.44 |
| 2026-03-16 / baseline | 1237.78 | -1213.71 | 260.61 | 9.47 |
| 2026-03-16 / funding_rank | 961.12 | -1057.21 | 133.90 | 2.59 |

Les contributions par stratégie et direction sont intégralement dans le JSON, positives et négatives incluses. Les différences de funding agrégées ne constituent pas une économie causale isolée : les entrées, tailles et trajectoires du portefeuille changent.

## Limites et vérifications

- Première matrice invalidée et archivée dans docs/invalid_boundary_initial : contrôle des ledgers a détecté des entrées après la fin de fenêtre suivies de clôtures datées avant l’entrée. Garde next-open <= end_ts_ms ajouté identiquement base/variante, puis 16 simulations répétées sans changer les hypothèses.
- Le ranking lit seulement des observations strictement antérieures au timestamp t de la bougie signal. Comme t désigne son ouverture, c’est un retard conservateur de 4 h par rapport à la décision à clôture. Tests de mutation du futur et de la borne exacte t.
- Aucun candidat supprimé par le ranking. Nombre de listes réordonnées par semestre : 277, 152, 76, 238. Un seul calcul sparse (troisième semestre, à chacun des deux coûts) reçoit le fallback neutre déclaré.
- 5 tests unitaires passent : futur exclu, signe short, priorité/égalité, préférence coût et population conservée, fallback sparse.
- Les 16 ledgers vérifient capital final = 500 + somme des PNL (erreur <1e-7) et entrées/sorties dans les bornes incluses/exclues. Comparaison aux baselines indépendantes du parent prévue après correction chronologique commune.
- Le DD du moteur est basé sur le capital réalisé. Les séries de panier et ledgers complets sont livrés pour contrôle MTM par le parent ; aucun DD intrabougie garanti.
- Funding du moteur : moyenne des échantillons dans le trade × durée × notionnel, pas une intégrale horaire exacte. Pas modifié pour cette comparaison.
- Snapshot OI TON finit en juin 2026 ; historique réutilisé après nombreuses recherches, pas un nouvel échantillon prospectif. Aucune prétention de rendement Live.

Code : `backtests/research_entry_funding_rank.py`, hook exclusivement dans la copie isolée du moteur. Protocole écrit avant le premier run : `docs/entry_funding_rank_protocol.md`.
