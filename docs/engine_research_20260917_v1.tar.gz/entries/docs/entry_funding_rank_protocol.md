# Protocole figé avant exécution : coût observé comme arbitrage de candidats

Une hypothèse / une variante, aucun sweep. Base HEAD e299fbdd7a0911547b088404579822a4bda439b8.
La priorité inter-stratégies reste z décroissant. À z égal, choisir d'abord le
plus faible coût signé de funding moyen observé sur les 24 heures STRICTEMENT
antérieures à l'horodatage de la bougie signal (donc conservativement avant sa
clôture), puis force décroissante. Funding positif coûte aux longs.
Moins de 3 observations dans la fenêtre : coût neutre 0 ; aucune exclusion.
Le fallback est déclaré et compté. Aucun financement futur ni PNL de trade ne
rentre dans la sélection. Cette variante n'est pas le filtre de crowding S5/S9
réfuté en juillet : aucune entrée n'est supprimée par seuil, seulement arbitrage
entre candidats simultanés. La faible variance du funding demeure une limite.

Capital initial 500 pour chaque semestre indépendant : [2024-09-16T12:00,
2025-03-16T12:00), puis jusqu'au 2025-09-16, 2026-03-16, 2026-09-16, toujours
12:00 UTC. Coûts aller-retour hors funding 13 et 15 bps ; funding historique,
aligned/margin_check/mfe_on_close/realistic_trail_booking vrais ; autres Params
inchangés (4 slots macro). Prix/OI snapshot macro, funding snapshot cascade.

Critère de poursuite fixé : gain strict dans au moins 3/4 semestres pour les
deux coûts, aucun semestre perdant de plus de 5 points du capital initial et DD
non aggravé de plus de 2 points. Ce critère autorise uniquement observation,
jamais déploiement automatique. Rapporter contributions positives/négatives,
concentration cinq meilleurs trades, nombre de listes effectivement réordonnées,
et manquants. Historique réutilisé : ce n'est PAS du hors-échantillon neuf.

Correction de validité après première exécution (sans retuning) : découverte indépendante au contrôle des ledgers et par le parent de trades entrés après la borne finale puis clôturés dans le passé. Première matrice invalide archivée docs/invalid_boundary_initial. Ajout garde next-open <= end_ts_ms dans moteur isolé, appliqué identiquement base/variante et aux trois branches de recherche, puis répétition des 16 runs.
