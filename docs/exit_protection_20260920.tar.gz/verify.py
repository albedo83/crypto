import gzip,json,hashlib,math
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent;result=json.loads((p/'result.json').read_text());inputs=json.load(gzip.open(p/'inputs.json.gz','rt'));digest=hashlib.sha256()
for (trade,ticks),row in zip(inputs,result['trades'],strict=True):
 digest.update(json.dumps([trade,ticks],sort_keys=True,allow_nan=False).encode())
 start=datetime.fromisoformat(trade['entry_time']).timestamp();end=datetime.fromisoformat(trade['exit_time']).timestamp()
 times=[start]+[t for t,v in ticks]+[end]
 covered=bool(ticks) and all(0<b-a<=120 for a,b in zip(times,times[1:]))
 assert covered==row['covered']
 if not covered:continue
 sign={'LONG':1,'SHORT':-1}[trade['direction']]
 returns=[sign*(price/trade['entry_price']-1)*10000 for t,price in ticks]
 candidates=[i for i,v in enumerate(returns[:-1]) if max([0]+returns[:i+1])>=1000 and v<=.5*max([0]+returns[:i+1])]
 assert bool(candidates)==row['triggered']
 if candidates:
  i=candidates[0];t,mark=ticks[i+1];fill=mark*(1-sign*.0002)
  expected=trade['size_usdt']*sign*(fill-trade['exit_price'])/trade['entry_price']
  assert math.isclose(expected,row['delta_price_usdt'],abs_tol=1e-8)
  assert start<row['trigger_ts']<t<end
assert digest.hexdigest()==result['input_sha256']
validation=dict(trades_checked=len(inputs),price_deltas_verified=True,chronology_verified=True,input_sha256=digest.hexdigest(),unit_tests_passed=7)
(p/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');print(validation)
